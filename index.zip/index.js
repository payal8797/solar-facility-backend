// index.js
const { ApolloServer } = require('apollo-server-express');
const express = require('express');
const {graphqlUploadExpress} = require('graphql-upload');

const mongoose = require('mongoose');
const typeDefs = require('./graphql/typeDefs');
const resolvers = require('./graphql/resolvers');

const MONGODB = "mongodb://localhost:27017";

const startServer = async () => {
  const app = express();

  // This middleware should be used before calling `applyMiddleware`
  app.use(graphqlUploadExpress({ maxFileSize: 10000000, maxFiles: 10 }));

  const server = new ApolloServer({
    typeDefs,
    resolvers,
  });

  await server.start();
  server.applyMiddleware({ app });

  mongoose.connect(MONGODB, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
      console.log("MongoDB Connected");
      app.listen({ port: 5000 }, () => {
        console.log(`Server running at http://localhost:5000${server.graphqlPath}`);
      });
    });
};

startServer();
