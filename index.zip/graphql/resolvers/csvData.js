const {GraphQLUpload}  = require('graphql-upload');
const CSVData = require('../../models/CSVData');
const parse = require('csv-parse');

module.exports = {
  Upload: GraphQLUpload,

  Mutation: {
    async uploadCSVFile(_, {file}) {
      const { createReadStream, filename, mimetype, encoding } = await file;
      // const pathName = path.join(__dirname, `../../uploads/${mimetype}`);
      console.log("file", file, createReadStream, filename, mimetype, encoding)

    //   const stream = createReadStream();
      return new Promise((resolve, reject) => {
        console.log("resolve",resolve);
        const parser = parse({
          columns: true,
          skip_empty_lines: true
        });

        stream.pipe(parser);

        parser.on('data', async (row) => {
          const { timestamp, activePower, energy } = row;

          const newData = new CSVData({
            timestamp: new Date(timestamp),
            activePower: parseFloat(activePower),
            energy: parseFloat(energy)
          });

          await newData.save();
        });

        parser.on('end', () => {
          resolve(`File ${filename} uploaded successfully`);
        });

        parser.on('error', (err) => {
          reject(`Error parsing CSV: ${err.message}`);
        });
      });
    }
  },

  Query: {
    async getCSVData() {
      try {
        const data = await CSVData.find();
        return data;
      } catch (err) {
        throw new Error(err);
      }
    }
  }
};
