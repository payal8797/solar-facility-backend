const mongoose = require('mongoose');

const csvDataSchema = new mongoose.Schema({
    timestamp: {
        type: Date,
        required: true
    },
    activePower: {
        type: Number,
        required: true
    },
    energy: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model('CSVData', csvDataSchema);
